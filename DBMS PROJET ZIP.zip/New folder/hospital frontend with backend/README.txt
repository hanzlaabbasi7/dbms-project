HOSPITAL MANAGEMENT SYSTEM – FRONTEND
====================================

Project Description
-------------------
This is the Frontend of a Hospital Management System developed using
HTML, CSS, and JavaScript. The frontend provides a modern dashboard
interface to manage patients, doctors, appointments, billing, and
medical records.

The frontend communicates with a backend REST API running on:
http://127.0.0.1:8000

It supports both XML and JSON data formats for compatibility.


Project Features
----------------
1. Dashboard Overview
   - Displays total number of patients, doctors, appointments, and bills.

2. Patient Management
   - Add new patients
   - View patient list
   - Edit patient details using a modal popup

3. Doctor Management
   - Add new doctors
   - View doctor list

4. Appointment Management
   - Schedule appointments
   - View upcoming appointments

5. Billing Management
   - Create bills
   - View billing records with payment status

6. Medical Records
   - Add medical records
   - View patient medical records

7. Responsive Design
   - Works on desktop, tablet, and mobile screens


Technologies Used
-----------------
- HTML5
- CSS3 (Responsive Design, Flexbox, Grid)
- JavaScript (ES6)
- Font Awesome Icons
- Google Fonts (Poppins)
- Fetch API for backend communication


Project Structure
-----------------
project-folder/
│
├── index.html        -> Main frontend page
├── style.css         -> Styling and layout
├── script.js         -> JavaScript logic and API calls
└── README.txt        -> Project documentation


Backend Requirements
--------------------
- Backend must be running on:
  http://127.0.0.1:8000

- Supported API Endpoints:
  /patients
  /patients/{id}
  /doctors
  /appointments
  /billing
  /medical-records

- The backend should accept:
  - XML (application/xml)
  - JSON (application/json)


How to Run the Frontend
----------------------
1. Make sure the backend server is running.
2. Open the project folder.
3. Open `index.html` in any modern web browser
   (Google Chrome, Firefox, Edge recommended).
4. The dashboard will automatically load data from the backend.


Important Notes
---------------
- If the backend is not running, the frontend will show connection errors.
- XML is tried first for API requests; JSON is used as a fallback.
- IDs (Patient ID, Doctor ID, etc.) must be unique.
- All data is fetched dynamically from the backend.


-------------------------------------------------------------
RUNNING THE SERVER : for the working or backend and front end
-------------------------------------------------------------
Activate the virtual environment:
    venv\Scripts\activate
Start the backend server using:
   uvicorn app.main:app --reload

Server will run at:
   http://127.0.0.1:8000
To check backend APIS:
    http://127.0.0.1:8000/docs
--------------------------------------------------
API ENDPOINTS
--------------------------------------------------

Screens Supported
-----------------
- Desktop
- Tablet
- Mobile (responsive layout)


Author
------
Developed as part of an academic project for a Hospital Management System.

Year: 2026
