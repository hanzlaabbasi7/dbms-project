// API Configuration
const API_BASE_URL = 'http://127.0.0.1:8000';

// DOM Elements
const patientForm = document.getElementById('patientForm');
const doctorForm = document.getElementById('doctorForm');
const appointmentForm = document.getElementById('appointmentForm');
const billingForm = document.getElementById('billingForm');
const recordForm = document.getElementById('recordForm');

// Add Edit Patient Modal to HTML
const editPatientModal = document.createElement('div');
editPatientModal.id = 'editPatientModal';
editPatientModal.className = 'modal';
editPatientModal.innerHTML = `
    <div class="modal-content">
        <span class="close-edit">&times;</span>
        <h2><i class="fas fa-edit"></i> Edit Patient</h2>
        <form id="editPatientForm">
            <input type="hidden" id="edit_patient_id">
            <input type="text" id="edit_first_name" placeholder="First Name" required>
            <input type="text" id="edit_last_name" placeholder="Last Name" required>
            <input type="date" id="edit_dob" required>
            <input type="text" id="edit_gender" placeholder="Gender (Male/Female)">
            <input type="tel" id="edit_contact" placeholder="Contact Number">
            <input type="email" id="edit_email" placeholder="Email">
            <button type="submit" class="btn-submit">Update Patient</button>
        </form>
    </div>
`;
document.body.appendChild(editPatientModal);

const closeEditModal = document.querySelector('.close-edit');
const editPatientForm = document.getElementById('editPatientForm');

// Modal Functions
if (closeEditModal) {
    closeEditModal.addEventListener('click', () => {
        editPatientModal.style.display = 'none';
    });
}

window.addEventListener('click', (e) => {
    if (e.target === editPatientModal) {
        editPatientModal.style.display = 'none';
    }
});

// Generic fetch function for XML
async function fetchData(endpoint) {
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`);
        if (response.ok) {
            const text = await response.text();
            console.log(`Raw response from ${endpoint}:`, text.substring(0, 200));
            
            // Try to parse as XML first
            try {
                const parser = new DOMParser();
                const xmlDoc = parser.parseFromString(text, "application/xml");
                
                // Check if it's valid XML (not an error)
                if (xmlDoc.getElementsByTagName("parsererror").length === 0) {
                    console.log(`Successfully parsed ${endpoint} as XML`);
                    return xmlDoc;
                }
            } catch (xmlError) {
                console.log(`Not valid XML for ${endpoint}, trying JSON`);
            }
            
            // Try to parse as JSON
            try {
                const jsonData = JSON.parse(text);
                console.log(`Successfully parsed ${endpoint} as JSON`);
                return jsonData;
            } catch (jsonError) {
                console.log(`Could not parse ${endpoint} as JSON either`);
            }
            
            return null;
        }
        return null;
    } catch (error) {
        console.error(`Error fetching ${endpoint}:`, error);
        return null;
    }
}

// Parse XML to count items
function countItemsFromXML(xmlDoc, tagName) {
    if (!xmlDoc || !xmlDoc.getElementsByTagName) return 0;
    const items = xmlDoc.getElementsByTagName(tagName);
    return items ? items.length : 0;
}

// Parse XML to array (for backward compatibility)
function xmlToArray(xmlDoc, tagName) {
    if (!xmlDoc || !xmlDoc.getElementsByTagName) return [];
    
    const items = xmlDoc.getElementsByTagName(tagName);
    const result = [];
    
    for (let i = 0; i < items.length; i++) {
        const item = items[i];
        const obj = {};
        
        // Convert all child elements to object properties
        for (let j = 0; j < item.children.length; j++) {
            const child = item.children[j];
            obj[child.tagName] = child.textContent;
        }
        
        result.push(obj);
    }
    
    return result;
}

// Load Dashboard Data
async function loadDashboardData() {
    console.log('Loading dashboard data...');
    
    try {
        // Load Patients
        const patientsData = await fetchData('/patients');
        let patientCount = 0;
        let patientsArray = [];
        
        if (patientsData && patientsData.getElementsByTagName) {
            // XML response
            patientCount = countItemsFromXML(patientsData, 'patient');
            patientsArray = xmlToArray(patientsData, 'patient');
        } else if (Array.isArray(patientsData)) {
            // JSON response (backward compatibility)
            patientCount = patientsData.length;
            patientsArray = patientsData;
        }
        
        document.getElementById('patientCount').textContent = patientCount;
        
        // Load Doctors
        const doctorsData = await fetchData('/doctors');
        let doctorCount = 0;
        let doctorsArray = [];
        
        if (doctorsData && doctorsData.getElementsByTagName) {
            doctorCount = countItemsFromXML(doctorsData, 'doctor');
            doctorsArray = xmlToArray(doctorsData, 'doctor');
        } else if (Array.isArray(doctorsData)) {
            doctorCount = doctorsData.length;
            doctorsArray = doctorsData;
        }
        
        document.getElementById('doctorCount').textContent = doctorCount;
        
        // Load Appointments
        const appointmentsData = await fetchData('/appointments');
        let appointmentCount = 0;
        let appointmentsArray = [];
        
        if (appointmentsData && appointmentsData.getElementsByTagName) {
            appointmentCount = countItemsFromXML(appointmentsData, 'appointment');
            appointmentsArray = xmlToArray(appointmentsData, 'appointment');
        } else if (Array.isArray(appointmentsData)) {
            appointmentCount = appointmentsData.length;
            appointmentsArray = appointmentsData;
        }
        
        document.getElementById('appointmentCount').textContent = appointmentCount;
        
        // Load Bills
        const billsData = await fetchData('/billing');
        let billCount = 0;
        let billsArray = [];
        
        if (billsData && billsData.getElementsByTagName) {
            billCount = countItemsFromXML(billsData, 'bill');
            billsArray = xmlToArray(billsData, 'bill');
        } else if (Array.isArray(billsData)) {
            billCount = billsData.length;
            billsArray = billsData;
        }
        
        document.getElementById('pendingBills').textContent = billCount;
        
        // Load Medical Records
        const recordsData = await fetchData('/medical-records');
        let recordsArray = [];
        
        if (recordsData && recordsData.getElementsByTagName) {
            recordsArray = xmlToArray(recordsData, 'medical_record');
        } else if (Array.isArray(recordsData)) {
            recordsArray = recordsData;
        }
        
        console.log('Medical records loaded:', recordsArray);
        
        // Populate tables
        populatePatientTable(patientsArray);
        populateDoctorTable(doctorsArray);
        populateAppointmentTable(appointmentsArray);
        populateBillingTable(billsArray);
        populateRecordTable(recordsArray);
        
    } catch (error) {
        console.error('Error loading data:', error);
    }
}

// ========== PATIENT FORM ==========
patientForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const patientData = {
        patient_id: parseInt(document.getElementById('patient_id').value),
        first_name: document.getElementById('first_name').value,
        last_name: document.getElementById('last_name').value,
        date_of_birth: document.getElementById('dob').value,
        gender: document.getElementById('gender').value || "",
        contact_number: document.getElementById('contact').value || "",
        email: document.getElementById('email').value || ""
    };
    
    console.log('Sending patient data:', patientData);
    
    // Try XML first, fall back to JSON
    const patientXML = `<?xml version="1.0" encoding="UTF-8"?>
<patient>
    <id>${patientData.patient_id}</id>
    <firstName>${patientData.first_name}</firstName>
    <lastName>${patientData.last_name}</lastName>
    <dateOfBirth>${patientData.date_of_birth}</dateOfBirth>
    <gender>${patientData.gender}</gender>
    <contactNumber>${patientData.contact_number}</contactNumber>
    <email>${patientData.email}</email>
</patient>`;
    
    try {
        // Try XML first
        const response = await fetch(`${API_BASE_URL}/patients`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/xml',
            },
            body: patientXML
        });
        
        if (response.ok) {
            alert('✅ Patient added successfully!');
            patientForm.reset();
            loadDashboardData();
        } else {
            // If XML fails, try JSON (for backward compatibility)
            console.log('XML failed, trying JSON...');
            const jsonResponse = await fetch(`${API_BASE_URL}/patients`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(patientData)
            });
            
            if (jsonResponse.ok) {
                alert('✅ Patient added successfully!');
                patientForm.reset();
                loadDashboardData();
            } else {
                const error = await jsonResponse.text();
                alert('❌ Failed to add patient: ' + error);
            }
        }
    } catch (error) {
        console.error('Error adding patient:', error);
        alert('⚠️ Connection error. Check backend is running.');
    }
});

// ========== DOCTOR FORM ==========
doctorForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const doctorData = {
        doctor_id: parseInt(document.getElementById('doctor_id').value),
        first_name: document.getElementById('doc_first_name').value,
        last_name: document.getElementById('doc_last_name').value,
        specialty: document.getElementById('specialty').value || "",
        contact_number: document.getElementById('doc_contact').value || "",
        email: document.getElementById('doc_email').value || ""
    };
    
    console.log('Sending doctor data:', doctorData);
    
    // Try XML first, fall back to JSON
    const doctorXML = `<?xml version="1.0" encoding="UTF-8"?>
<doctor>
    <id>${doctorData.doctor_id}</id>
    <firstName>${doctorData.first_name}</firstName>
    <lastName>${doctorData.last_name}</lastName>
    <specialty>${doctorData.specialty}</specialty>
    <contactNumber>${doctorData.contact_number}</contactNumber>
    <email>${doctorData.email}</email>
</doctor>`;
    
    try {
        const response = await fetch(`${API_BASE_URL}/doctors`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/xml',
            },
            body: doctorXML
        });
        
        if (response.ok) {
            alert('✅ Doctor added successfully!');
            doctorForm.reset();
            loadDashboardData();
        } else {
            // Fall back to JSON
            const jsonResponse = await fetch(`${API_BASE_URL}/doctors`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(doctorData)
            });
            
            if (jsonResponse.ok) {
                alert('✅ Doctor added successfully!');
                doctorForm.reset();
                loadDashboardData();
            } else {
                alert('❌ Failed to add doctor');
            }
        }
    } catch (error) {
        console.error('Error adding doctor:', error);
        alert('⚠️ Connection error. Check backend.');
    }
});

// ========== APPOINTMENT FORM ==========
appointmentForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const appointmentData = {
        appointment_id: parseInt(document.getElementById('appointment_id').value),
        patient_id: parseInt(document.getElementById('app_patient_id').value),
        doctor_id: parseInt(document.getElementById('app_doctor_id').value),
        appointment_date: document.getElementById('app_date').value,
        appointment_time: document.getElementById('app_time').value,
        reason: document.getElementById('app_reason').value || ""
    };
    
    console.log('Sending appointment data:', appointmentData);
    
    // Try XML first, fall back to JSON
    const appointmentXML = `<?xml version="1.0" encoding="UTF-8"?>
<appointment>
    <id>${appointmentData.appointment_id}</id>
    <patientId>${appointmentData.patient_id}</patientId>
    <doctorId>${appointmentData.doctor_id}</doctorId>
    <appointmentDate>${appointmentData.appointment_date}</appointmentDate>
    <appointmentTime>${appointmentData.appointment_time}</appointmentTime>
    <reason>${appointmentData.reason}</reason>
</appointment>`;
    
    try {
        const response = await fetch(`${API_BASE_URL}/appointments`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/xml',
            },
            body: appointmentXML
        });
        
        if (response.ok) {
            alert('✅ Appointment scheduled successfully!');
            appointmentForm.reset();
            loadDashboardData();
        } else {
            // Fall back to JSON
            const jsonResponse = await fetch(`${API_BASE_URL}/appointments`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(appointmentData)
            });
            
            if (jsonResponse.ok) {
                alert('✅ Appointment scheduled successfully!');
                appointmentForm.reset();
                loadDashboardData();
            } else {
                alert('❌ Failed to schedule appointment');
            }
        }
    } catch (error) {
        console.error('Error scheduling appointment:', error);
    }
});

// ========== BILLING FORM ==========
billingForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const appointmentId = document.getElementById('bill_appointment_id').value;
    
    const billingData = {
        bill_id: parseInt(document.getElementById('bill_id').value),
        patient_id: parseInt(document.getElementById('bill_patient_id').value),
        appointment_id: appointmentId ? parseInt(appointmentId) : null,
        total_amount: parseFloat(document.getElementById('total_amount').value),
        payment_method: document.getElementById('payment_method').value || "Cash"
    };
    
    console.log('Sending billing data:', billingData);
    
    // Try XML first, fall back to JSON
    const billingXML = `<?xml version="1.0" encoding="UTF-8"?>
<bill>
    <id>${billingData.bill_id}</id>
    <patientId>${billingData.patient_id}</patientId>
    <appointmentId>${billingData.appointment_id || ""}</appointmentId>
    <totalAmount>${billingData.total_amount}</totalAmount>
    <paymentMethod>${billingData.payment_method}</paymentMethod>
</bill>`;
    
    try {
        const response = await fetch(`${API_BASE_URL}/billing`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/xml',
            },
            body: billingXML
        });
        
        if (response.ok) {
            alert('✅ Bill created successfully!');
            billingForm.reset();
            loadDashboardData();
        } else {
            // Fall back to JSON
            const jsonResponse = await fetch(`${API_BASE_URL}/billing`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(billingData)
            });
            
            if (jsonResponse.ok) {
                alert('✅ Bill created successfully!');
                billingForm.reset();
                loadDashboardData();
            } else {
                alert('❌ Failed to create bill');
            }
        }
    } catch (error) {
        console.error('Error creating bill:', error);
    }
});

// ========== MEDICAL RECORDS FORM ==========
if (recordForm) {
    recordForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const recordData = {
            record_id: parseInt(document.getElementById('record_id').value),
            patient_id: parseInt(document.getElementById('record_patient_id').value),
            doctor_id: parseInt(document.getElementById('record_doctor_id').value),
            appointment_id: document.getElementById('record_appointment_id').value || null,
            diagnosis: document.getElementById('diagnosis').value || "",
            treatment: document.getElementById('treatment').value || "",
            prescription: document.getElementById('prescription').value || ""
        };
        
        console.log('Sending medical record data:', recordData);
        
        // Try XML first, fall back to JSON
        const recordXML = `<?xml version="1.0" encoding="UTF-8"?>
<medicalRecord>
    <id>${recordData.record_id}</id>
    <patientId>${recordData.patient_id}</patientId>
    <doctorId>${recordData.doctor_id}</doctorId>
    <appointmentId>${recordData.appointment_id || ""}</appointmentId>
    <diagnosis>${recordData.diagnosis}</diagnosis>
    <treatment>${recordData.treatment}</treatment>
    <prescription>${recordData.prescription}</prescription>
</medicalRecord>`;
        
        try {
            const response = await fetch(`${API_BASE_URL}/medical-records`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/xml',
                },
                body: recordXML
            });
            
            if (response.ok) {
                alert('✅ Medical record added successfully!');
                recordForm.reset();
                loadDashboardData();
            } else {
                // Fall back to JSON
                const jsonResponse = await fetch(`${API_BASE_URL}/medical-records`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(recordData)
                });
                
                if (jsonResponse.ok) {
                    alert('✅ Medical record added successfully!');
                    recordForm.reset();
                    loadDashboardData();
                } else {
                    alert('❌ Failed to add record');
                }
            }
        } catch (error) {
            console.error('Error adding record:', error);
            alert('⚠️ Connection error. Check backend.');
        }
    });
}

// ========== PATIENT EDIT FUNCTIONALITY ==========
async function fetchPatientById(patientId) {
    try {
        const response = await fetch(`${API_BASE_URL}/patients/${patientId}`);
        if (response.ok) {
            const text = await response.text();
            
            // Try XML first
            try {
                const parser = new DOMParser();
                const xmlDoc = parser.parseFromString(text, "application/xml");
                if (xmlDoc.getElementsByTagName("parsererror").length === 0) {
                    return xmlDoc;
                }
            } catch (xmlError) {
                // Not XML, try JSON
                try {
                    return JSON.parse(text);
                } catch (jsonError) {
                    console.error('Could not parse as XML or JSON:', text);
                }
            }
        }
        throw new Error('Failed to fetch patient');
    } catch (error) {
        console.error('Error fetching patient:', error);
        return null;
    }
}

function openEditPatientModal(patient) {
    if (!patient) return;
    
    let patientId, firstName, lastName, dob, gender, contact, email;
    
    if (patient.getElementsByTagName) {
        // XML
        patientId = patient.getElementsByTagName('patient_id')[0]?.textContent || 
                   patient.getElementsByTagName('id')[0]?.textContent;
        firstName = patient.getElementsByTagName('first_name')[0]?.textContent || 
                   patient.getElementsByTagName('firstName')[0]?.textContent;
        lastName = patient.getElementsByTagName('last_name')[0]?.textContent || 
                  patient.getElementsByTagName('lastName')[0]?.textContent;
        dob = patient.getElementsByTagName('date_of_birth')[0]?.textContent || 
             patient.getElementsByTagName('dateOfBirth')[0]?.textContent;
        gender = patient.getElementsByTagName('gender')[0]?.textContent || '';
        contact = patient.getElementsByTagName('contact_number')[0]?.textContent || 
                 patient.getElementsByTagName('contactNumber')[0]?.textContent || '';
        email = patient.getElementsByTagName('email')[0]?.textContent || '';
    } else {
        // JSON
        patientId = patient.patient_id || patient.id;
        firstName = patient.first_name;
        lastName = patient.last_name;
        dob = patient.date_of_birth;
        gender = patient.gender || '';
        contact = patient.contact_number || '';
        email = patient.email || '';
    }
    
    document.getElementById('edit_patient_id').value = patientId;
    document.getElementById('edit_first_name').value = firstName;
    document.getElementById('edit_last_name').value = lastName;
    document.getElementById('edit_dob').value = dob;
    document.getElementById('edit_gender').value = gender;
    document.getElementById('edit_contact').value = contact;
    document.getElementById('edit_email').value = email;
    
    editPatientModal.style.display = 'block';
}

if (editPatientForm) {
    editPatientForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const patientId = document.getElementById('edit_patient_id').value;
        
        const patientData = {
            first_name: document.getElementById('edit_first_name').value,
            last_name: document.getElementById('edit_last_name').value,
            date_of_birth: document.getElementById('edit_dob').value,
            gender: document.getElementById('edit_gender').value,
            contact_number: document.getElementById('edit_contact').value,
            email: document.getElementById('edit_email').value
        };
        
        // Try XML first, fall back to JSON
        const patientXML = `<?xml version="1.0" encoding="UTF-8"?>
<patient>
    <firstName>${patientData.first_name}</firstName>
    <lastName>${patientData.last_name}</lastName>
    <dateOfBirth>${patientData.date_of_birth}</dateOfBirth>
    <gender>${patientData.gender}</gender>
    <contactNumber>${patientData.contact_number}</contactNumber>
    <email>${patientData.email}</email>
</patient>`;
        
        try {
            const response = await fetch(`${API_BASE_URL}/patients/${patientId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/xml',
                },
                body: patientXML
            });
            
            if (response.ok) {
                alert('✅ Patient updated successfully!');
                editPatientModal.style.display = 'none';
                loadDashboardData();
            } else {
                // Fall back to JSON
                const jsonResponse = await fetch(`${API_BASE_URL}/patients/${patientId}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(patientData)
                });
                
                if (jsonResponse.ok) {
                    alert('✅ Patient updated successfully!');
                    editPatientModal.style.display = 'none';
                    loadDashboardData();
                } else {
                    alert('❌ Failed to update patient');
                }
            }
        } catch (error) {
            console.error('Error updating patient:', error);
            alert('⚠️ Connection error');
        }
    });
}

// ========== TABLE POPULATION FUNCTIONS ==========
function populatePatientTable(patients) {
    const tbody = document.querySelector('#patientTable tbody');
    tbody.innerHTML = '';
    
    patients?.forEach(patient => {
        const patientId = patient.patient_id || patient.id;
        const firstName = patient.first_name || patient.firstName;
        const lastName = patient.last_name || patient.lastName;
        const dob = patient.date_of_birth || patient.dateOfBirth;
        const contact = patient.contact_number || patient.contactNumber || 'N/A';
        
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${patientId}</td>
            <td>${firstName} ${lastName}</td>
            <td>${dob}</td>
            <td>${contact}</td>
            <td>
                <button class="btn-action edit-patient" data-id="${patientId}">
                    <i class="fas fa-edit"></i> Edit
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
    
    attachPatientTableListeners();
}

function attachPatientTableListeners() {
    document.querySelectorAll('.edit-patient').forEach(button => {
        button.addEventListener('click', async (e) => {
            const patientId = button.getAttribute('data-id');
            const patient = await fetchPatientById(patientId);
            if (patient) {
                openEditPatientModal(patient);
            } else {
                alert('Could not load patient details');
            }
        });
    });
}

function populateDoctorTable(doctors) {
    const tbody = document.querySelector('#doctorTable tbody');
    tbody.innerHTML = '';
    
    doctors?.forEach(doctor => {
        const doctorId = doctor.doctor_id || doctor.id;
        const firstName = doctor.first_name || doctor.firstName;
        const lastName = doctor.last_name || doctor.lastName;
        const specialty = doctor.specialty || 'General';
        const contact = doctor.contact_number || doctor.contactNumber || 'N/A';
        
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${doctorId}</td>
            <td>Dr. ${firstName} ${lastName}</td>
            <td>${specialty}</td>
            <td>${contact}</td>
        `;
        tbody.appendChild(row);
    });
}

function populateAppointmentTable(appointments) {
    const tbody = document.querySelector('#appointmentTable tbody');
    tbody.innerHTML = '';
    
    appointments?.forEach(appointment => {
        const appointmentId = appointment.appointment_id || appointment.id;
        const patientId = appointment.patient_id || appointment.patientId;
        const doctorId = appointment.doctor_id || appointment.doctorId;
        const date = appointment.appointment_date || appointment.appointmentDate;
        const time = appointment.appointment_time || appointment.appointmentTime;
        const status = appointment.status || 'Scheduled';
        
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${appointmentId}</td>
            <td>Patient ${patientId}</td>
            <td>Dr. ${doctorId}</td>
            <td>${date}</td>
            <td>${time}</td>
            <td><span class="status-badge">${status}</span></td>
        `;
        tbody.appendChild(row);
    });
}

function populateBillingTable(bills) {
    const tbody = document.querySelector('#billingTable tbody');
    tbody.innerHTML = '';
    
    bills?.forEach(bill => {
        const billId = bill.bill_id || bill.id;
        const patientId = bill.patient_id || bill.patientId;
        const amount = bill.total_amount || bill.totalAmount;
        const status = bill.payment_status || 'Pending';
        const date = bill.bill_date || 'N/A';
        
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${billId}</td>
            <td>${patientId}</td>
            <td>$${amount}</td>
            <td><span class="status-badge ${status}">${status}</span></td>
            <td>${date}</td>
        `;
        tbody.appendChild(row);
    });
}

function populateRecordTable(records) {
    const tbody = document.querySelector('#recordTable tbody');
    if (!tbody) {
        console.error('Medical records table body not found!');
        return;
    }
    
    tbody.innerHTML = '';
    
    if (!records || records.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td colspan="4" style="text-align: center; padding: 20px; color: #666;">
                <i class="fas fa-info-circle"></i> No medical records found.
            </td>
        `;
        tbody.appendChild(row);
        return;
    }
    
    records?.forEach(record => {
        const recordId = record.record_id || record.id;
        const patientId = record.patient_id || record.patientId;
        const doctorId = record.doctor_id || record.doctorId;
        const diagnosis = record.diagnosis || 'N/A';
        
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${recordId}</td>
            <td>${patientId}</td>
            <td>${doctorId}</td>
            <td>${diagnosis}</td>
        `;
        tbody.appendChild(row);
    });
}

// Smooth scrolling for navigation
document.querySelectorAll('.nav-links a').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const targetId = this.getAttribute('href').substring(1);
        const targetSection = document.getElementById(targetId);
        if (targetSection) {
            targetSection.scrollIntoView({ behavior: 'smooth' });
        }
    });
});

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    console.log('Hospital Management Frontend Loaded');
    loadDashboardData();
});