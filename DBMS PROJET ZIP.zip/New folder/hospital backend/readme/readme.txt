===============================
HOSPITAL MANAGEMENT SYSTEM
BACKEND (FASTAPI + XML)
===============================

Project Type:
-------------
Hospital Management System – Backend API

Technology Stack:
-----------------
• Python 3.9+
• FastAPI
• Uvicorn (ASGI Server)
• SQL Server (Express)
• pyodbc
• pydantic-xml
• XML-based REST APIs

This backend provides XML-based RESTful APIs for managing hospital operations
including patients, doctors, appointments, billing, and medical records.
The backend is designed to work with a separate frontend (HTML/CSS/JavaScript).

--------------------------------------------------
FEATURES
--------------------------------------------------
• Patient Management (Add, View, Update)
• Doctor Management (Add, View)
• Appointment Scheduling (Add, View)
• Billing Management (Add, View)
• Medical Records Management (Add, View)
• XML request and response handling
• SQL Server database integration
• CORS enabled for frontend communication

--------------------------------------------------
PROJECT STRUCTURE
--------------------------------------------------
app/
│
├── main.py                → FastAPI app entry point
├── database.py            → SQL Server database connection
├── models.py              → XML models using pydantic-xml
│
├── patients.py            → Patient APIs
├── doctors.py             → Doctor APIs
├── appointments.py        → Appointment APIs
├── billing.py             → Billing APIs
├── medical_records.py     → Medical Records APIs
│
└── requirements.txt       → Python dependencies

--------------------------------------------------
DATABASE
--------------------------------------------------
Database Name:
hospital_management

Database Type:
Microsoft SQL Server (SQL Express)

Connection:
• Uses Windows Authentication (Trusted Connection)
• Configured in database.py

Required Tables:
• Patients
• Doctors
• Appointments
• Billing
• Medical_Records

(Note: Tables must exist before running the backend)

--------------------------------------------------
INSTALLATION & SETUP
--------------------------------------------------

1. Clone or copy the backend project folder

2. Create a virtual environment (recommended):
   python -m venv venv
   venv\Scripts\activate   (Windows)
   source venv/bin/activate (Linux/Mac)

3. Install dependencies:
   pip install -r requirements.txt

4. Ensure SQL Server is running and database exists

5. Update database connection if needed:
   File: app/database.py

--------------------------------------------------
RUNNING THE SERVER
--------------------------------------------------
Activate the virtual environment:
    venv\Scripts\activate
Start the backend server using:
   uvicorn app.main:app --reload

Server will run at:
   http://127.0.0.1:8000
To check backend APIS:
    http://127.0.0.1:8000/docs
--------------------------------------------------
API ENDPOINTS
--------------------------------------------------

Patients:
---------
POST    /patients
GET     /patients
GET     /patients/{patient_id}
PUT     /patients/{patient_id}

Doctors:
--------
POST    /doctors
GET     /doctors

Appointments:
-------------
POST    /appointments
GET     /appointments

Billing:
--------
POST    /billing
GET     /billing

Medical Records:
----------------
POST    /medical-records
GET     /medical-records

--------------------------------------------------
REQUEST & RESPONSE FORMAT
--------------------------------------------------

• All POST and PUT requests accept XML payloads
• All responses are returned in XML format
• JSON fallback support exists in frontend (for compatibility)

Example Content-Type:
   application/xml

--------------------------------------------------
CORS CONFIGURATION
--------------------------------------------------

CORS is enabled to allow frontend access from:
• http://127.0.0.1:3000
• http://localhost:3000
• http://127.0.0.1:8000
• file:// (for local HTML files)
• All origins (for development/testing)

--------------------------------------------------
FRONTEND INTEGRATION
--------------------------------------------------

This backend is designed to work with:
• HTML
• CSS
• JavaScript (Fetch API)

Frontend connects to:
   http://127.0.0.1:8000

--------------------------------------------------
DEVELOPED FOR
--------------------------------------------------
Academic / Educational Project  
Hospital Management System  
FastAPI + XML-based APIs

--------------------------------------------------
AUTHOR:Hanzla Seemab
--------------------------------------------------
Student Project – Hospital Management System

--------------------------------------------------
END OF README
--------------------------------------------------
