from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.patients import router as patient_router
from app.doctors import router as doctor_router
from app.appointments import router as appointment_router
from app.billing import router as billing_router
from app.medical_records import router as medical_router
#from app.auth import router as auth_router
#from app.users import router as user_router

# Create app
app = FastAPI(title="Hospital Management Backend")

# 🔥 ADD CORS MIDDLEWARE HERE 🔥
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://127.0.0.1:3000",  # Live Server
        "http://localhost:3000",   # Localhost Live Server
        "http://127.0.0.1:8000",   # Backend itself
        "http://localhost:8000",   # Backend localhost
        "null",                    # file:// URLs
        "*"                        # All origins (for testing)
    ],
    allow_credentials=True,
    allow_methods=["*"],  # Allow all methods
    allow_headers=["*"],  # Allow all headers
)

# Include routers
app.include_router(patient_router, prefix="/patients", tags=["Patients"])
app.include_router(doctor_router, prefix="/doctors", tags=["Doctors"])
app.include_router(appointment_router, prefix="/appointments", tags=["Appointments"])
app.include_router(billing_router, prefix="/billing", tags=["Billing"])
app.include_router(medical_router, prefix="/medical-records", tags=["Medical Records"])
#app.include_router(auth_router, prefix="/auth", tags=["Auth"])
#app.include_router(user_router, prefix="/users", tags=["Users"])

@app.get("/")
def home():
    return {"message": "Hospital Management Backend Running"}