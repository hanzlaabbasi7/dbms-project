
from fastapi import APIRouter, HTTPException, Response
from app.database import get_db_connection
from app.models import PatientCreateXml, PatientUpdateXml

router = APIRouter()

@router.post("/", response_class=Response)
async def add_patient_xml(patient: PatientCreateXml):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO Patients (patient_id, first_name, last_name, date_of_birth, gender, contact_number, email)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, patient.patient_id, patient.first_name, patient.last_name, 
         patient.date_of_birth, patient.gender, patient.contact_number, patient.email)

    conn.commit()
    conn.close()

    return Response(content=patient.to_xml(), media_type="application/xml")

@router.get("/", response_class=Response)
async def get_patients_xml():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM Patients")
    rows = cursor.fetchall()

    patients = []
    for row in rows:
        patients.append({
            "patient_id": row.patient_id,
            "first_name": row.first_name,
            "last_name": row.last_name,
            "date_of_birth": str(row.date_of_birth),
            "gender": row.gender,
            "contact_number": row.contact_number,
            "email": row.email
        })

    conn.close()
    
    xml_content = '<?xml version="1.0" encoding="UTF-8"?>\n<patients>\n'
    for patient in patients:
        xml_content += f'  <patient>\n'
        xml_content += f'    <patient_id>{patient["patient_id"]}</patient_id>\n'
        xml_content += f'    <first_name>{patient["first_name"]}</first_name>\n'
        xml_content += f'    <last_name>{patient["last_name"]}</last_name>\n'
        xml_content += f'    <date_of_birth>{patient["date_of_birth"]}</date_of_birth>\n'
        xml_content += f'    <gender>{patient["gender"] or ""}</gender>\n'
        xml_content += f'    <contact_number>{patient["contact_number"] or ""}</contact_number>\n'
        xml_content += f'    <email>{patient["email"] or ""}</email>\n'
        xml_content += f'  </patient>\n'
    xml_content += '</patients>'
    
    return Response(content=xml_content, media_type="application/xml")

@router.get("/{patient_id}", response_class=Response)
async def get_patient_xml(patient_id: int):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM Patients WHERE patient_id = ?", patient_id)
    row = cursor.fetchone()
    
    if not row:
        raise HTTPException(status_code=404, detail="Patient not found")
    
    xml_content = f'''<?xml version="1.0" encoding="UTF-8"?>
<patient>
    <patient_id>{row.patient_id}</patient_id>
    <first_name>{row.first_name}</first_name>
    <last_name>{row.last_name}</last_name>
    <date_of_birth>{str(row.date_of_birth)}</date_of_birth>
    <gender>{row.gender or ""}</gender>
    <contact_number>{row.contact_number or ""}</contact_number>
    <email>{row.email or ""}</email>
</patient>'''
    
    conn.close()
    return Response(content=xml_content, media_type="application/xml")

@router.put("/{patient_id}", response_class=Response)
async def update_patient_xml(patient_id: int, patient: PatientUpdateXml):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    try:
        cursor.execute("""
            UPDATE Patients 
            SET first_name = ?, last_name = ?, date_of_birth = ?, 
                gender = ?, contact_number = ?, email = ?
            WHERE patient_id = ?
        """, patient.first_name, patient.last_name, patient.date_of_birth,
             patient.gender, patient.contact_number, patient.email, patient_id)
        
        if cursor.rowcount == 0:
            raise HTTPException(status_code=404, detail="Patient not found")
            
        conn.commit()
        
        xml_response = f'''<?xml version="1.0" encoding="UTF-8"?>
<response>
    <message>Patient updated successfully</message>
    <patient_id>{patient_id}</patient_id>
</response>'''
        
        return Response(content=xml_response, media_type="application/xml")
        
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        conn.close()
