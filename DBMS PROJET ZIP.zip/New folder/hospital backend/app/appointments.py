from fastapi import APIRouter, Response
from app.database import get_db_connection
from app.models import AppointmentCreateXml

router = APIRouter()

@router.post("/", response_class=Response)
async def create_appointment_xml(appointment: AppointmentCreateXml):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO Appointments
        (appointment_id, patient_id, doctor_id, appointment_date, appointment_time, reason)
        VALUES (?, ?, ?, ?, ?, ?)
    """, appointment.appointment_id, appointment.patient_id, appointment.doctor_id,
         appointment.appointment_date, appointment.appointment_time, appointment.reason)

    conn.commit()
    conn.close()

    return Response(content=appointment.to_xml(), media_type="application/xml")

@router.get("/", response_class=Response)
async def get_appointments_xml():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM Appointments")
    rows = cursor.fetchall()

    appointments = []
    for row in rows:
        appointments.append({
            "appointment_id": row.appointment_id,
            "patient_id": row.patient_id,
            "doctor_id": row.doctor_id,
            "appointment_date": str(row.appointment_date),
            "appointment_time": row.appointment_time,
            "status": row.status,
            "reason": row.reason
        })

    conn.close()
    
    xml_content = '<?xml version="1.0" encoding="UTF-8"?>\n<appointments>\n'
    for app in appointments:
        xml_content += f'  <appointment>\n'
        xml_content += f'    <appointment_id>{app["appointment_id"]}</appointment_id>\n'
        xml_content += f'    <patient_id>{app["patient_id"]}</patient_id>\n'
        xml_content += f'    <doctor_id>{app["doctor_id"]}</doctor_id>\n'
        xml_content += f'    <appointment_date>{app["appointment_date"]}</appointment_date>\n'
        xml_content += f'    <appointment_time>{app["appointment_time"]}</appointment_time>\n'
        xml_content += f'    <status>{app["status"]}</status>\n'
        xml_content += f'    <reason>{app["reason"] or ""}</reason>\n'
        xml_content += f'  </appointment>\n'
    xml_content += '</appointments>'
    
    return Response(content=xml_content, media_type="application/xml")