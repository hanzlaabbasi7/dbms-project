from typing import Optional
from pydantic_xml import BaseXmlModel, element

# ========== PATIENT MODELS ==========
class PatientCreateXml(BaseXmlModel, tag="patient"):
    patient_id: int = element(tag="id")
    first_name: str = element(tag="firstName")
    last_name: str = element(tag="lastName")
    date_of_birth: str = element(tag="dateOfBirth")
    gender: Optional[str] = element(tag="gender", default=None)
    contact_number: Optional[str] = element(tag="contactNumber", default=None)
    email: Optional[str] = element(tag="email", default=None)

class PatientUpdateXml(BaseXmlModel, tag="patient"):
    first_name: str = element(tag="firstName")
    last_name: str = element(tag="lastName")
    date_of_birth: str = element(tag="dateOfBirth")
    gender: Optional[str] = element(tag="gender", default=None)
    contact_number: Optional[str] = element(tag="contactNumber", default=None)
    email: Optional[str] = element(tag="email", default=None)

# ========== DOCTOR MODELS ==========
class DoctorCreateXml(BaseXmlModel, tag="doctor"):
    doctor_id: int = element(tag="id")
    first_name: str = element(tag="firstName")
    last_name: str = element(tag="lastName")
    specialty: Optional[str] = element(tag="specialty", default=None)
    contact_number: Optional[str] = element(tag="contactNumber", default=None)
    email: Optional[str] = element(tag="email", default=None)

# ========== APPOINTMENT MODELS ==========
class AppointmentCreateXml(BaseXmlModel, tag="appointment"):
    appointment_id: int = element(tag="id")
    patient_id: int = element(tag="patientId")
    doctor_id: int = element(tag="doctorId")
    appointment_date: str = element(tag="appointmentDate")
    appointment_time: str = element(tag="appointmentTime")
    reason: Optional[str] = element(tag="reason", default=None)

# ========== BILLING MODELS ==========
class BillingCreateXml(BaseXmlModel, tag="bill"):
    bill_id: int = element(tag="id")
    patient_id: int = element(tag="patientId")
    appointment_id: Optional[int] = element(tag="appointmentId", default=None)
    total_amount: float = element(tag="totalAmount")
    payment_method: Optional[str] = element(tag="paymentMethod", default=None)

# ========== MEDICAL RECORD MODELS ==========
class MedicalRecordCreateXml(BaseXmlModel, tag="medicalRecord"):
    record_id: int = element(tag="id")
    patient_id: int = element(tag="patientId")
    doctor_id: int = element(tag="doctorId")
    appointment_id: Optional[int] = element(tag="appointmentId", default=None)
    diagnosis: Optional[str] = element(tag="diagnosis", default=None)
    treatment: Optional[str] = element(tag="treatment", default=None)
    prescription: Optional[str] = element(tag="prescription", default=None)