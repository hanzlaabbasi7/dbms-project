
from fastapi import APIRouter, Response
from app.database import get_db_connection
from app.models import MedicalRecordCreateXml

router = APIRouter()

@router.post("/", response_class=Response)
async def add_record_xml(record: MedicalRecordCreateXml):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO Medical_Records
        (record_id, patient_id, doctor_id, appointment_id,
         diagnosis, treatment, prescription)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, record.record_id, record.patient_id, record.doctor_id,
         record.appointment_id, record.diagnosis, record.treatment,
         record.prescription)

    conn.commit()
    conn.close()

    return Response(content=record.to_xml(), media_type="application/xml")

@router.get("/", response_class=Response)
async def get_records_xml():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM Medical_Records")
    rows = cursor.fetchall()

    records = []
    for r in rows:
        records.append({
            "record_id": r.record_id,
            "patient_id": r.patient_id,
            "doctor_id": r.doctor_id,
            "appointment_id": r.appointment_id,
            "diagnosis": r.diagnosis,
            "treatment": r.treatment,
            "prescription": r.prescription
        })

    conn.close()
    
    xml_content = '<?xml version="1.0" encoding="UTF-8"?>\n<medical_records>\n'
    for record in records:
        xml_content += f'  <medical_record>\n'
        xml_content += f'    <record_id>{record["record_id"]}</record_id>\n'
        xml_content += f'    <patient_id>{record["patient_id"]}</patient_id>\n'
        xml_content += f'    <doctor_id>{record["doctor_id"]}</doctor_id>\n'
        xml_content += f'    <appointment_id>{record["appointment_id"] or ""}</appointment_id>\n'
        xml_content += f'    <diagnosis>{record["diagnosis"] or ""}</diagnosis>\n'
        xml_content += f'    <treatment>{record["treatment"] or ""}</treatment>\n'
        xml_content += f'    <prescription>{record["prescription"] or ""}</prescription>\n'
        xml_content += f'  </medical_record>\n'
    xml_content += '</medical_records>'
    
    return Response(content=xml_content, media_type="application/xml")
