from fastapi import APIRouter, Response
from app.database import get_db_connection
from app.models import BillingCreateXml

router = APIRouter()

@router.post("/", response_class=Response)
async def create_bill_xml(bill: BillingCreateXml):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO Billing
        (bill_id, patient_id, appointment_id, total_amount, payment_method)
        VALUES (?, ?, ?, ?, ?)
    """, bill.bill_id, bill.patient_id, bill.appointment_id,
         bill.total_amount, bill.payment_method)

    conn.commit()
    conn.close()

    return Response(content=bill.to_xml(), media_type="application/xml")

@router.get("/", response_class=Response)
async def get_bills_xml():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM Billing")
    rows = cursor.fetchall()

    data = []
    for r in rows:
        data.append({
            "bill_id": r.bill_id,
            "patient_id": r.patient_id,
            "appointment_id": r.appointment_id,
            "total_amount": float(r.total_amount),
            "amount_paid": float(r.amount_paid) if r.amount_paid else 0.0,
            "payment_status": r.payment_status,
            "payment_method": r.payment_method,
            "bill_date": str(r.bill_date) if r.bill_date else None
        })

    conn.close()
    
    xml_content = '<?xml version="1.0" encoding="UTF-8"?>\n<bills>\n'
    for bill in data:
        xml_content += f'  <bill>\n'
        xml_content += f'    <bill_id>{bill["bill_id"]}</bill_id>\n'
        xml_content += f'    <patient_id>{bill["patient_id"]}</patient_id>\n'
        xml_content += f'    <appointment_id>{bill["appointment_id"] or ""}</appointment_id>\n'
        xml_content += f'    <total_amount>{bill["total_amount"]}</total_amount>\n'
        xml_content += f'    <amount_paid>{bill["amount_paid"]}</amount_paid>\n'
        xml_content += f'    <payment_status>{bill["payment_status"] or ""}</payment_status>\n'
        xml_content += f'    <payment_method>{bill["payment_method"] or ""}</payment_method>\n'
        xml_content += f'    <bill_date>{bill["bill_date"] or ""}</bill_date>\n'
        xml_content += f'  </bill>\n'
    xml_content += '</bills>'
    
    return Response(content=xml_content, media_type="application/xml")