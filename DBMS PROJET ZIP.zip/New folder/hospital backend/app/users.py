from fastapi import APIRouter, HTTPException
from app.database import get_db_connection
from app.models import BaseModel
from app.security import hash_password

router = APIRouter()

class UserCreate(BaseModel):
    username: str
    password: str
    role: str

@router.post("/register")
def register(user: UserCreate):
    conn = get_db_connection()
    cursor = conn.cursor()

    hashed_pwd = hash_password(user.password)

    cursor.execute("""
        INSERT INTO Users (username, password, role)
        VALUES (?, ?, ?)
    """,
    user.username,
    hashed_pwd,
    user.role)

    conn.commit()
    conn.close()

    return {"message": "User registered successfully"}
