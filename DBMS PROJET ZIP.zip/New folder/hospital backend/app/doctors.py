from fastapi import APIRouter, Response
from app.database import get_db_connection
from app.models import DoctorCreateXml

router = APIRouter()

@router.post("/", response_class=Response)
async def add_doctor_xml(doctor: DoctorCreateXml):
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO Doctors (doctor_id, first_name, last_name, specialty, contact_number, email)
        VALUES (?, ?, ?, ?, ?, ?)
    """, doctor.doctor_id, doctor.first_name, doctor.last_name,
         doctor.specialty, doctor.contact_number, doctor.email)

    conn.commit()
    conn.close()

    return Response(content=doctor.to_xml(), media_type="application/xml")

@router.get("/", response_class=Response)
async def get_doctors_xml():
    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM Doctors")
    rows = cursor.fetchall()

    doctors = []
    for row in rows:
        doctors.append({
            "doctor_id": row.doctor_id,
            "first_name": row.first_name,
            "last_name": row.last_name,
            "specialty": row.specialty,
            "contact_number": row.contact_number,
            "email": row.email
        })

    conn.close()
    
    xml_content = '<?xml version="1.0" encoding="UTF-8"?>\n<doctors>\n'
    for doctor in doctors:
        xml_content += f'  <doctor>\n'
        xml_content += f'    <doctor_id>{doctor["doctor_id"]}</doctor_id>\n'
        xml_content += f'    <first_name>{doctor["first_name"]}</first_name>\n'
        xml_content += f'    <last_name>{doctor["last_name"]}</last_name>\n'
        xml_content += f'    <specialty>{doctor["specialty"] or ""}</specialty>\n'
        xml_content += f'    <contact_number>{doctor["contact_number"] or ""}</contact_number>\n'
        xml_content += f'    <email>{doctor["email"] or ""}</email>\n'
        xml_content += f'  </doctor>\n'
    xml_content += '</doctors>'
    
    return Response(content=xml_content, media_type="application/xml")